package com.example.magazyn.repository;

import com.example.magazyn.entity.Company;
import com.example.magazyn.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findAllByCompany(Company company);

}